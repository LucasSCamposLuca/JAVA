package com.example.ProjetoSenai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoSenaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
