package com.example.ProjetoSenai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoSenaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoSenaiApplication.class, args);
	}

}
